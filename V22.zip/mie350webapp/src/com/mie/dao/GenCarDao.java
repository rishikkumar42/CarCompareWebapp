package com.mie.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mie.model.GenCar;
import com.mie.util.DbUtil;

public class GenCarDao {
	/**
	 * This class handles all of the GenCar-related methods
	 * (get).
	 */

	private Connection connection;

	public GenCarDao() {
		/**
		 * Get the database connection.
		 */
		connection = DbUtil.getConnection();
	}

	
	public void addCar(GenCar gencar) {
		/**
		 * This method adds a new car to the database.
		 */
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("insert into Car_R(CarCompany,CarMake,Year,MSRPLow,MSRPHigh,Type,FormFactor) values (?, ?, ?, ?, ?, ? )");
			// Parameters start with 1
			preparedStatement.setString(1, gencar.getCarCompany());
			preparedStatement.setString(2, gencar.getCarMake()); 
			preparedStatement.setInt(3, gencar.getYear()); 			
			preparedStatement.setInt(4, gencar.getMSRPLow());
			preparedStatement.setInt(5, gencar.getMSRPHigh());
			preparedStatement.setString(6, gencar.getType());
			preparedStatement.setString(7, gencar.getFormFactor());
			//preparedStatement.setString(8, gencar.getImagePath());
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	public List<GenCar> getAllCars() {
		/**
		 * This method returns the list of all cars in the form of a List
		 * object.
		 */
		List<GenCar> gencars = new ArrayList<GenCar>();
		try {
			Statement statement = connection.createStatement();
			// System.out.println("getting cars from table");
			ResultSet rs = statement.executeQuery("select * from Car_R");
			while (rs.next()) {
				GenCar gencar = new GenCar();
				gencar.setCarCompany(rs.getString("CarCompany"));
				gencar.setCarMake(rs.getString("CarMake"));
				gencar.setYear(rs.getInt("Year"));
				gencar.setMSRPLow(rs.getInt("MSRPLow"));
				gencar.setMSRPHigh(rs.getInt("MSRPHigh"));
				gencar.setType(rs.getString("Type"));
				gencar.setFormFactor(rs.getString("FormFactor"));
				//gencar.setImagePath(rs.getString("ImagePath"));
				gencars.add(gencar);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return gencars;
	}

	public GenCar getCarById(int carid) {
		/**
		 * This method retrieves a car by their CarID number.
		 * 
		 * Currently not used in the sample web app, but code is left here for
		 * your review.
		 */
		GenCar gencar = new GenCar();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from Car_R where CarCompany=?");
			preparedStatement.setInt(1, carid);
			ResultSet rs = preparedStatement.executeQuery();

			if (rs.next()) {
				gencar.setCarCompany(rs.getString("CarCompany"));
				gencar.setCarMake(rs.getString("CarMake"));
				gencar.setYear(rs.getInt("Year"));
				gencar.setMSRPLow(rs.getInt("MSRPLow"));
				gencar.setMSRPHigh(rs.getInt("MSRPHigh"));
				gencar.setType(rs.getString("Type"));
				gencar.setFormFactor(rs.getString("FormFactor"));
				//gencar.setImagePath(rs.getString("ImagePath"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return gencar;
	}

	public List<GenCar> getCarByKeyword(String keyword) {
		/**
		 * This method retrieves a list of cars that matches the keyword
		 * entered by the user.
		 */
		List<GenCar> gencars = new ArrayList<GenCar>();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from Car_R where CarCompany LIKE ? OR CarMake LIKE ? OR Year LIKE ? OR Type LIKE ? OR FormFactor LIKE ?");

			preparedStatement.setString(1, "%" + keyword + "%");
			preparedStatement.setString(2, "%" + keyword + "%");
			preparedStatement.setString(3, "%" + keyword + "%");
			preparedStatement.setString(4, "%" + keyword + "%");
			preparedStatement.setString(5, "%" + keyword + "%");
			
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				GenCar gencar = new GenCar();
				gencar.setCarCompany(rs.getString("CarCompany"));
				gencar.setCarMake(rs.getString("CarMake"));
				gencar.setYear(rs.getInt("Year"));
				gencar.setMSRPLow(rs.getInt("MSRPLow"));
				gencar.setMSRPHigh(rs.getInt("MSRPHigh"));
				gencar.setType(rs.getString("Type"));
				gencar.setFormFactor(rs.getString("FormFactor"));
				//gencar.setImagePath(rs.getString("ImagePath"));
				gencars.add(gencar);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return gencars;
	}
	
	public List<GenCar> getTopCarModels() {
		/**
		 * This method retrieves a list of top car models based on their ranking in the database
		 */
		List<GenCar> gencars = new ArrayList<GenCar>();
		try {
			Statement statement = connection.createStatement();
			// System.out.println("getting cars from table");
			ResultSet rs = statement.executeQuery("select * from Car_R where Ranking = 1 OR Ranking = 2 OR Ranking = 3 OR Ranking = 4 OR Ranking = 5");
			while (rs.next()) {
				GenCar gencar = new GenCar();
				gencar.setCarCompany(rs.getString("CarCompany"));
				gencar.setCarMake(rs.getString("CarMake"));
				gencar.setYear(rs.getInt("Year"));
				gencar.setMSRPLow(rs.getInt("MSRPLow"));
				gencar.setMSRPHigh(rs.getInt("MSRPHigh"));
				gencar.setType(rs.getString("Type"));
				gencar.setFormFactor(rs.getString("FormFactor"));
				gencar.setImagePath(rs.getString("imgPath"));
				gencars.add(gencar);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return gencars;
		
		
		
	}
	
	

}
