package com.mie.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mie.model.Car;
import com.mie.model.UserSavedList;
import com.mie.util.DbUtil;

public class CarDao {
	/**
	 * This class handles all of the Car-related methods
	 * (get).
	 */

	private Connection connection = null;

	public CarDao() {
		/**
		 * Get the database connection.
		 */
		connection = DbUtil.getConnection();
	}

	
	public void addCar(Car car) {
		/**
		 * This method adds a new car to the database.
		 */
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("insert into CarModels_R(CarID,CarModel,CarMake,MSRP,TypeSpec,Engine,Transmission,Seats,Drivetrain,CityMPG,HighwayMPG,CombinedMPG) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )");
			// Parameters start with 1
			preparedStatement.setInt(1, car.getCarID());
			preparedStatement.setString(2, car.getCarModel());
			preparedStatement.setString(3, car.getCarMake()); 
			preparedStatement.setInt(4, car.getMSRP());
			preparedStatement.setString(5, car.getTypeSpec());
			preparedStatement.setString(6, car.getHorsePower());
			preparedStatement.setString(6, car.getEnginerCap());
			preparedStatement.setString(6, car.getcylinders());
			preparedStatement.setString(7, car.getTransmission());
			preparedStatement.setInt(8, car.getSeats());
			preparedStatement.setString(9, car.getDriveTrain());
			preparedStatement.setInt(10, car.getCityMPG());
			preparedStatement.setInt(11, car.getHighwayMPG());
			preparedStatement.setInt(12, car.getCombinedMPG());
			preparedStatement.setString(13, car.getImagePath());
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	
	public List<Car> getAllCars() {
		/**
		 * This method returns the list of all cars in the form of a List
		 * object.
		 */
		List<Car> cars = new ArrayList<Car>();
		try {
			Statement statement = connection.createStatement();
			// System.out.println("getting cars from table");
			ResultSet rs = statement.executeQuery("select * from CarModels_R");
			while (rs.next()) {
				Car car = new Car();
				car.setCarID(rs.getInt("CarID"));
				car.setCarModel(rs.getString("CarModel"));
				car.setCarMake(rs.getString("CarMake"));
				car.setMSRP(rs.getInt("MSRP"));
				car.setTypeSpec(rs.getString("TypeSpec"));
				car.setHorsePower(rs.getString("HorsePower"));
				car.setEnginerCap(rs.getString("EnginerCap"));
				car.setcylinders(rs.getString("cylinders"));
				car.setTransmission(rs.getString("Transmission"));
				car.setSeats(rs.getInt("Seats"));
				car.setDriveTrain(rs.getString("DriveTrain"));
				car.setCityMPG(rs.getInt("CityMPG"));
				car.setHighwayMPG(rs.getInt("HighwayMPG"));
				car.setCombinedMPG(rs.getInt("CombinedMPG"));
				car.setImagePath(rs.getString("ImagePath"));
				cars.add(car);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return cars;
	}

	public Car getCarById(int carid) {
		/**
		 * This method retrieves a car by their CarID number.
		 * 
		 * Currently not used in the sample web app, but code is left here for
		 * your review.
		 */
		Car car = new Car();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from CarModels_R where CarID=?");
			preparedStatement.setInt(1, carid);
			ResultSet rs = preparedStatement.executeQuery();

			if (rs.next()) {
				car.setCarID(rs.getInt("CarID"));
				car.setCarModel(rs.getString("CarModel"));
				car.setCarMake(rs.getString("CarMake"));
				car.setMSRP(rs.getInt("MSRP"));
				car.setTypeSpec(rs.getString("TypeSpec"));
				car.setHorsePower(rs.getString("HorsePower"));
				car.setEnginerCap(rs.getString("EnginerCap"));
				car.setcylinders(rs.getString("cylinders"));
				car.setTransmission(rs.getString("Transmission"));
				car.setSeats(rs.getInt("Seats"));
				car.setDriveTrain(rs.getString("DriveTrain"));
				car.setCityMPG(rs.getInt("CityMPG"));
				car.setHighwayMPG(rs.getInt("HighwayMPG"));
				car.setCombinedMPG(rs.getInt("CombinedMPG"));
				car.setImagePath(rs.getString("ImagePath"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return car;
	}

	public List<Car> getCarByKeyword(String keyword) {
		/**
		 * This method retrieves a list of cars that matches the keyword
		 * entered by the user.
		 */
		List<Car> cars = new ArrayList<Car>();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from CarModels_R where CarModel LIKE ? OR CarMake LIKE ? OR TypeSpec LIKE ? OR EnginerCap LIKE ? OR Transmission LIKE ? OR Seats LIKE ? OR CarID LIKE ?");

			preparedStatement.setString(1, "%" + keyword + "%");
			preparedStatement.setString(2, "%" + keyword + "%");
			preparedStatement.setString(3, "%" + keyword + "%");
			preparedStatement.setString(4, "%" + keyword + "%");
			preparedStatement.setString(5, "%" + keyword + "%");
			preparedStatement.setString(6, "%" + keyword + "%");
			preparedStatement.setString(7, "%" + keyword + "%");
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				Car car = new Car();
				car.setCarID(rs.getInt("CarID"));
				car.setCarModel(rs.getString("CarModel"));
				car.setCarMake(rs.getString("CarMake"));
				car.setMSRP(rs.getInt("MSRP"));
				car.setTypeSpec(rs.getString("TypeSpec"));
				car.setHorsePower(rs.getString("HorsePower"));
				car.setEnginerCap(rs.getString("EnginerCap"));
				car.setcylinders(rs.getString("cylinders"));
				car.setTransmission(rs.getString("Transmission"));
				car.setSeats(rs.getInt("Seats"));
				car.setDriveTrain(rs.getString("DriveTrain"));
				car.setCityMPG(rs.getInt("CityMPG"));
				car.setHighwayMPG(rs.getInt("HighwayMPG"));
				car.setCombinedMPG(rs.getInt("CombinedMPG"));
				car.setImagePath(rs.getString("ImagePath"));
				car.setTransmissionName(rs.getString("TransmissionName"));
				car.setTypespecName(rs.getString("TypespecName"));
				car.setDrivetrainName(rs.getString("DrivetrainName"));
				cars.add(car);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return cars;
	}
	
	public List<Car> getCarByPreference(ArrayList<String> preferenceList,ArrayList<String> preferenceListValue) {
		/**
		 * This method retrieves a shrinking list of cars that are 
		 * closest to the preference value inputed by user
		 **/
		List<Car> cars = new ArrayList<Car>();
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("SELECT TOP 3 * FROM CarModels_R ORDER BY  ABS( ? - ? ), ABS(? - ?), ABS( ? -? ), ABS(? - ?), ABS( ? -? ), ABS(? - ?), ABS( ? -? );");

			preparedStatement.setString(1, preferenceList.get(0));
			preparedStatement.setString(2, preferenceListValue.get(0));
			preparedStatement.setString(3, preferenceList.get(1));
			preparedStatement.setString(4, preferenceListValue.get(1));
			preparedStatement.setString(5, preferenceList.get(2));
			preparedStatement.setString(6, preferenceListValue.get(2));
			preparedStatement.setString(7, preferenceList.get(3));
			preparedStatement.setString(8, preferenceListValue.get(3));
			preparedStatement.setString(9, preferenceList.get(4));
			preparedStatement.setString(10, preferenceListValue.get(4));
			preparedStatement.setString(11, preferenceList.get(5));
			preparedStatement.setString(12, preferenceListValue.get(5));
			preparedStatement.setString(13, preferenceList.get(6));
			preparedStatement.setString(14, preferenceListValue.get(6));
			
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				Car car = new Car();
				car.setCarID(rs.getInt("CarID"));
				car.setCarModel(rs.getString("CarModel"));
				car.setCarMake(rs.getString("CarMake"));
				car.setMSRP(rs.getInt("MSRP"));
				car.setTypeSpec(rs.getString("TypeSpec"));
				car.setHorsePower(rs.getString("HorsePower"));
				car.setEnginerCap(rs.getString("EnginerCap"));
				car.setcylinders(rs.getString("cylinders"));
				car.setTransmission(rs.getString("Transmission"));
				car.setSeats(rs.getInt("Seats"));
				car.setDriveTrain(rs.getString("DriveTrain"));
				car.setCityMPG(rs.getInt("CityMPG"));
				car.setHighwayMPG(rs.getInt("HighwayMPG"));
				car.setCombinedMPG(rs.getInt("CombinedMPG"));
				car.setImagePath(rs.getString("ImagePath"));
				cars.add(car);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return cars;
	}
	
	public List<UserSavedList> getCarFromSavedList(String username) {
		
		/**
		 * This method retrieves a list of cars that matches the keyword
		 * entered by the user.
		 */
		List<UserSavedList> cars = new ArrayList<UserSavedList>();
		
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("select * from UserSavedList_R where username = ?");

			preparedStatement.setString(1, username);
			
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				
				UserSavedList car = new UserSavedList();
				car.setUsername(rs.getString("username")); 
				car.setCarid(rs.getInt("CarID"));
				car.setCarMake(rs.getString("CarMake"));
				car.setCarModel(rs.getString("CarModel"));
				car.setYear(rs.getInt("Year"));
				car.setMSRP(rs.getInt("MSRP"));
				
				cars.add(car);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		return cars;
	}
	
	public void addSavedCar (UserSavedList usl){
		
		/**
		 * This method adds a new car to the database.
		 */
		PreparedStatement preparedStatement =  null; 
		try {
			
			connection = DbUtil.getConnection();
			
			preparedStatement = connection
					.prepareStatement("insert into UserSavedList_R(username,CarID,CarMake,CarModel,Year,MSRP) values (?, ?, ?, ?, ?, ? )");
			// Parameters start with 1
			preparedStatement.setString(1, usl.getUsername());
			preparedStatement.setInt(2, usl.getCarid());
			preparedStatement.setString(3, usl.getCarMake()); 
			preparedStatement.setString(4, usl.getCarModel());
			preparedStatement.setInt(5, usl.getYear());
			preparedStatement.setInt(6, usl.getMSRP());

			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}


	public void removeSavedCar(int carID) {
		// TODO Auto-generated method stub
		
		/**
		 * This method deletes a a saved car from the database
		 */
		try {
			PreparedStatement preparedStatement = connection
					.prepareStatement("delete from UserSavedList_R where CarID=?");
			// Parameters start with 1
			preparedStatement.setInt(1, carID);
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

}
