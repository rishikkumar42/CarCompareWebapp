package com.mie.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.mie.util.DbUtil;
import com.mie.model.*;
import com.mie.controller.*;
import com.mie.util.*;

public class UserDao {

	/**
	 * This class handles the User objects and the login component of the web
	 * app.
	 */
	static Connection currentCon = null;
	static ResultSet rs = null;

	public static User login(User user) {

		/**
		 * This method attempts to find the user that is trying to log in by
		 * first retrieving the username and password entered by the user.
		 */
		Statement stmt = null;

		String username = user.getUsername();
		String password = user.getPassword();

		/**
		 * Prepare a query that searches the users table in the database
		 * with the given username and password.
		 */
		String searchQuery = "select * from User_R where username='"
				+ username + "' AND password='" + password + "'";

		try {
			// connect to DB
			currentCon = DbUtil.getConnection();
			stmt = currentCon.createStatement();
			rs = stmt.executeQuery(searchQuery);
			boolean more = rs.next();

			/**
			 * If there are no results from the query, set the user to false.
			 * The person attempting to log in will be redirected to the home
			 * page when isValid is false.
			 */
			
			if (!more) {
				user.setValid(false);
			}

			/**
			 * If the query results in an database entry that matches the
			 * username and password, assign the appropriate information to
			 * the User object.
			 */
			else if (more) {
				String firstName = rs.getString("FirstName");
				String lastName = rs.getString("LastName");

				user.setFirstName(firstName);
				user.setLastName(lastName);
				user.setValid(true);
			}
		}

		catch (Exception ex) {
			System.out.println("Log In failed: An Exception has occurred! "
					+ ex);
		}
		/**
		 * Return the User object.
		 */
		return user;

	}
	
	public static String register(User user)
    {
       
        
        //Connection con = null;
        PreparedStatement preparedStatement = null;         
        try
        {
        	 String username = user.getUsername();
     		String firstname = user.getFirstName();
             String lastname = user.getLastName();
             String password = user.getPassword(); 
        	// connect to DB
        	currentCon = DbUtil.getConnection();
            String query = "insert into User_R(username,FirstName,LastName,password) values (?, ?, ?, ? )"; //Insert user details into the table 'User_R'
            
            preparedStatement = currentCon.prepareStatement(query); //Making use of prepared statements here to insert bunch of data
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, firstname);
            preparedStatement.setString(3, lastname);
            preparedStatement.setString(4, password);

            preparedStatement.executeUpdate();
            
            int i= preparedStatement.executeUpdate();
            
            if (i!=0)  //Just to ensure data has been inserted into the database
            return "SUCCESS"; 
        }
        catch(SQLException e)
        {
           e.printStackTrace();      
        }       
        return "Oops.. Something went wrong..!";  // On failure, send a message from here.
    }
	
	public void addPreferences(User user) {
		/**
		 * This method adds preferences to the database.
		 */
		try {
			PreparedStatement preparedStatement = currentCon
					.prepareStatement("insert into UserPref_R(Type, Transmission, DriveTrain, PriceRangeH, PriceRangeL) values (?, ?, ?, ?, ? )");
			// Parameters start with 1
			preparedStatement.setDouble(1, user.getPreferences().get(0));
			preparedStatement.setDouble(2, user.getPreferences().get(1));
			preparedStatement.setDouble(3, user.getPreferences().get(2));
			preparedStatement.setDouble(4, user.getPreferences().get(3));
			preparedStatement.setDouble(5, user.getPreferences().get(4));
			preparedStatement.executeUpdate();

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public static User preferences(User user) {

		/**
		 * This method attempts to find the member that is currently logged in and obtains their car preferences by
		 * first retrieving the userid.
		 */
		Statement stmt = null;

		String userid = user.getUsername();

		/**
		 * Prepare a query that searches the UserPref_R table in the database
		 * with the given usernameprivate ArrayList<Double> preferences;private ArrayList<Double> preferences;private ArrayList<Double> preferences;private ArrayList<Double> preferences;private ArrayList<Double> preferences;private ArrayList<Double> preferences;private ArrayList<Double> preferences;.
		 */
		String searchQuery = "select * from UserPref_R where userid='"
				+ userid + "'";

		try {
			// connect to DB
			currentCon = DbUtil.getConnection();
			stmt = currentCon.createStatement();
			rs = stmt.executeQuery(searchQuery);
			boolean more = rs.next();

			/**
			 * If the query results in an database entry that matches the
			 * userid, assign the appropriate information to
			 * the User object.
			 */
			if (more) {
				ArrayList<Double> preferences = new ArrayList<Double>();
				Double type = (double) rs.getInt("Type");
				Double transmission = (double) rs.getInt("Transmission");
				Double drivetrain = (double) rs.getInt("Drivetrain");
				Double priceRangeH = (double) rs.getInt("PriceRangeH");
				Double priceRangeL = (double) rs.getInt("PriceRangeL");
				
				preferences.add(type);
				preferences.add(transmission);
				preferences.add(drivetrain);
				preferences.add(priceRangeH);
				preferences.add(priceRangeL);

				user.setPreferences(preferences);
			}
		}

		catch (Exception ex) {
			System.out.println("No preferences found! "
					+ ex);
		}
		/**
		 * Return the Member object.
		 */
		return user;

	}

	public static String registerPref(UserPref preference) {
		 //Connection con = null;
        PreparedStatement preparedStatement = null;  
        
        try
        {
        	String username = preference.getUserid();
     		String pref1 = preference.getPreferenceOne();
     		String pref2 = preference.getPreferenceTwo();
     		String pref3 = preference.getPreferenceThree();
     		String pref4 = preference.getPreferenceFour();
     		String pref5 = preference.getPreferenceFive();
     		String pref6 = preference.getPreferenceSix();
     		String pref7 = preference.getPreferenceSeven();
        	// connect to DB
        	currentCon = DbUtil.getConnection();
            String query1 = "update UserPref_R set one=?, two=?, three=?, four=?, five=?, six=?, seven=? where username=?"; //Insert user preferences details into the table 'UsePrefr_R'
            
            preparedStatement = currentCon.prepareStatement(query1); //Making use of prepared statements here to insert bunch of data
            
            preparedStatement.setString(1, pref1);
            preparedStatement.setString(2, pref2);
            preparedStatement.setString(3, pref3);
            preparedStatement.setString(4, pref4);
            preparedStatement.setString(5, pref5);
            preparedStatement.setString(6, pref6);
            preparedStatement.setString(7, pref7);
            preparedStatement.setString(8, username);

            preparedStatement.executeUpdate();
            
            int i= preparedStatement.executeUpdate();
            
           if (i!=0)  //Just to ensure data has been inserted into the database
           return "SUCCESS"; 
        }
        catch(SQLException e)
        {
           e.printStackTrace();      
        }       
        return "Oops.. Something went wrong..!";  // On failure, send a message from here.
	}
	
	public static String addUserToPref (String username){
		 //Connection con = null;
        PreparedStatement preparedStatement = null;  
        
        try
        {
        	
        	// connect to DB
        	currentCon = DbUtil.getConnection();
            String query1 = "insert into UserPref_R(username,one,two,three,four,five,six,seven) values (?, ?, ?, ?, ?, ?, ?, ? )"; //Insert user preferences details into the table 'UsePrefr_R'
            
            preparedStatement = currentCon.prepareStatement(query1); //Making use of prepared statements here to insert bunch of data
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, "");
            preparedStatement.setString(3, "");
            preparedStatement.setString(4, "");
            preparedStatement.setString(5, "");
            preparedStatement.setString(6, "");
            preparedStatement.setString(7, "");
            preparedStatement.setString(8, "");

            preparedStatement.executeUpdate();
            
            int i= preparedStatement.executeUpdate();
            
           if (i!=0)  //Just to ensure data has been inserted into the database
           return "SUCCESS"; 
        }
        catch(SQLException e)
        {
           e.printStackTrace();      
        }       
        return "Oops.. Something went wrong..!";  // On failure, send a message from here.
	}
}