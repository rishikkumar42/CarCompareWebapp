package com.mie.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mie.dao.CarDao;
import com.mie.model.Car;
import com.mie.util.DbUtil;

public class SearchController extends HttpServlet {
	/**
	 * This class only handles the SEARCH feature of the web app.
	 * 
	 * These are variables that lead to the appropriate JSP pages.
	 * 
	 * SEARCH_USER leads to the search results page.
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static String SEARCH_USER = "/SearchCarResult.jsp";
	private static String LOGGED_IN_SEARCH = "/SearchCarResultLogged.jsp";
	private static String ALGO_RESULT = "/algoResults.jsp";
	private static String VIEW_DET = "/moreDetails.jsp"; 
	private static String VIEW_DET_LOG = "/moreDetailsLogged.jsp";
	private CarDao dao;
	private Connection connection = null;

	/**
	 * Constructor for this class.
	 */
	public SearchController() {
		super();
		dao = new CarDao();
		connection = DbUtil.getConnection();
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		/**
		 * This method handles the retrieval of the search keyword entered by
		 * the user.
		 */
		String forward = "";
		String action = request.getParameter("action");
		
		if (action.equals("SearchControl")){
			
			String keyword = request.getParameter("keyword");
			forward = SEARCH_USER; 
			request.setAttribute("keyword", keyword);
			request.setAttribute("CarModels_R", dao.getCarByKeyword(keyword));

		}else if (action.equals("loggedInSearch")){
			String keyword = request.getParameter("keyword");
			
			forward = LOGGED_IN_SEARCH; 
			request.setAttribute("keyword", keyword);
			request.setAttribute("CarModels_R", dao.getCarByKeyword(keyword));
		}
		else if (action.equals("viewDetails")){
			String keyword = request.getParameter("keyword");
			
			forward = VIEW_DET; 
			request.setAttribute("keyword", keyword);
			request.setAttribute("CarModels_R", dao.getCarByKeyword(keyword));
		}
		else if (action.equals("viewDetailsLogged")){
			String keyword = request.getParameter("keyword");
			
			forward = VIEW_DET_LOG; 
			request.setAttribute("keyword", keyword);
			request.setAttribute("CarModels_R", dao.getCarByKeyword(keyword));
		}
		else if (action.equals("pref")){
			
			HttpSession session = request.getSession();
			String username = (String) session.getAttribute("username");
			
			ArrayList<String> preferenceList = new ArrayList<String>();
			ArrayList<String> preferenceListValue = new ArrayList<String>();
			
			//PreparedStatement preparedStatement;
			//	preparedStatement = connection.prepareStatement("Select * from UserPref_R Where username = ?");
			//	preparedStatement.setString(1, username);//how to make work for current user.
			//	ResultSet rs = preparedStatement.executeQuery();
				
				//for(int i = 0; i< ((ArrayList<String>) rs).size(); i++){
				//	String[] splitted = rs.getString(i).split(",");
				//	preferenceList.add(splitted[0]);
				//	preferenceListValue.add(splitted[1]);
				//}
				//while (rs.next()){
					
				//}
				preferenceList.add(0, "MSRP");
				preferenceList.add(1, "HorsePower");
				preferenceList.add(2, "DriveTrain");
				preferenceList.add(3, "TypeSpec");
				preferenceList.add(4, "CombinedMPG");
				preferenceList.add(5, "Seats");
				preferenceList.add(6, "cylinders"); 
				
				preferenceListValue.add(0, "18500"); 
				preferenceListValue.add(1, "132");
				preferenceListValue.add(2, "0");
				preferenceListValue.add(3, "1");
				preferenceListValue.add(4, "32");
				preferenceListValue.add(5, "5");
				preferenceListValue.add(6, "4");
				forward = ALGO_RESULT;
				
				
				request.setAttribute("CarModels_R", dao.getCarByPreference(preferenceList, preferenceListValue));
				
		
		}
		
		
		RequestDispatcher view = request.getRequestDispatcher(forward);
		view.forward(request, response);
	}
}