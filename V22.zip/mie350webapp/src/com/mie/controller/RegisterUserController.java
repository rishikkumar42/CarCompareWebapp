package com.mie.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 



import com.mie.dao.CarDao;
import com.mie.dao.UserDao;
import com.mie.model.User;
 
public class RegisterUserController extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public RegisterUserController() {
    	 super();
 		new UserDao();
     }
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Copying all the input parameters in to local variables
         String username = request.getParameter("username");
         String firstname = request.getParameter("firstName");
         String lastname = request.getParameter("lastName");
         String password = request.getParameter("password");
         
         User user = new User();
        //Using Java Beans - An easiest way to play with group of related data
         user.setUsername(username); 
         user.setFirstName(firstname);
         user.setLastName(lastname);
         user.setPassword(password);
         
         UserDao UserDao = new UserDao();
         
        //The core Logic of the Registration application is present here. We are going to insert user data in to the database.
         String userRegistered = UserDao.register(user);
         String userPrefReg = UserDao.addUserToPref(username); 
         
         if(userRegistered.equals("SUCCESS"))   //On success, you can display a message to user on Home page
         {
            request.getRequestDispatcher("/index.jsp").forward(request, response);
         }
         else   //On Failure, display a meaningful message to the User.
         {
            request.setAttribute("errMessage", userRegistered);
            request.getRequestDispatcher("/login.jsp").forward(request, response);
         }
     }
}
