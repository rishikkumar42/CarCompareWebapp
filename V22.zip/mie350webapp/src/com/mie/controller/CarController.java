package com.mie.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mie.dao.CarDao;
import com.mie.model.Car;
import com.mie.model.User;
import com.mie.model.UserSavedList;

public class CarController extends HttpServlet {
	/**
	 * This class handles all insert/edit/list functions of the servlet.
	 * 
	 * LIST_CAR_PUBLIC leads to the public listing of cars.
	 * LIST_CAR_ADMIN leads to the admin-only listing of cars
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static String LIST_SAVED= "/savedList.jsp";
	private static String SAVE = "/SearchCarResultLogged.jsp"; 
	private CarDao dao;

	/**
	 * Constructor for this class.
	 */
	public CarController() {
		super();
		dao = new CarDao();
	}

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		/**
		 * This class retrieves the appropriate 'action' found on the JSP pages: 
		 * 
		 * - listCar will direct the servlet to the public listing of all cars in the
		 * database. 
		 * - listCarAdmin will direct the servlet to the admin
		 * listing of all cars in the database.
		 */
		String forward = "";
		String action = request.getParameter("action");

		if(action.equals("savedList")){
			forward = LIST_SAVED; 
			
			//User member = new User();
			HttpSession session = request.getSession();
			String username = (String) session.getAttribute("username");
			
			request.setAttribute("UserSavedList_R", dao.getCarFromSavedList(username));	
			
		}else if (action.equals("save")){
			forward = SAVE; 
		}
		RequestDispatcher view = request.getRequestDispatcher(forward);
		view.forward(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession();
		String username = (String) session.getAttribute("username");
		
		String action = request.getParameter("action");
		
		String carID = request.getParameter("carID"); 
		
		
		String carMake = request.getParameter("carMake"); 
				
				
		String carModel = request.getParameter("carModel"); 
		int year = 2019; 
		String MSRP = request.getParameter("MSRP");
		
		String addOrRem = request.getParameter("addOrRemove"); 
		

		UserSavedList usl = new UserSavedList(); 
		
		usl.setUsername(username);
		usl.setCarid(Integer.parseInt(carID));
		usl.setCarMake(carMake);
		usl.setCarModel(carModel);
		usl.setYear(year);
		usl.setMSRP(Integer.parseInt(MSRP));	
		
		
		
		//create method that adds usl into UserSavedList_R 
		CarDao cd = new CarDao();
		
		if (action.equals("add")){
			dao.addSavedCar(usl);
		}
		
		else if (action.equals("remove")){
			dao.removeSavedCar(Integer.parseInt(carID)); 
		}
		
		RequestDispatcher view = request
				.getRequestDispatcher("/savedList.jsp");
		
		
		request.setAttribute("UserSavedList_R", dao.getCarFromSavedList(username));	
		view.forward(request, response);
		
	}

}