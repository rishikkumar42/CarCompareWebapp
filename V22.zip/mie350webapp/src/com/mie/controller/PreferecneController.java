package com.mie.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.ArrayList;


import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
 



import javax.servlet.http.HttpSession;

import com.mie.dao.CarDao;
//import com.mie.dao.PreferenceDao;
import com.mie.dao.UserDao;
import com.mie.model.User;
import com.mie.model.UserPref;
 
public class PreferecneController extends HttpServlet {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Object user;
	private UserDao dao; 
	
	public PreferecneController() {
    	 super();
 		dao = new UserDao();
     }
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //Copying all the input parameters in to local variables
		
         
     	HttpSession session = request.getSession();
		String username = (String) session.getAttribute("username");
		
		String action = request.getParameter("action");
		
		//pulls the users ranking preferences 
		String rank1 = request.getParameter("r1");
        String rank2 = request.getParameter("r2");
        String rank3 = request.getParameter("r3");
        String rank4 = request.getParameter("r4");
        String rank5 = request.getParameter("r5");
        String rank6 = request.getParameter("r6");
        String rank7 = request.getParameter("r7");
        
        //pulls the users specific paramaters for their preferences (e.g MSRP is 14000)
        String pref1 = request.getParameter(rank1);
        String pref2 = request.getParameter(rank2);
        String pref3 = request.getParameter(rank3);
        String pref4 = request.getParameter(rank4);
        String pref5 = request.getParameter(rank5);
        String pref6 = request.getParameter(rank6);
        String pref7 = request.getParameter(rank7);     
         
        //Combines the ranking and custom paramater to enter into the database. 
        String tuple1 = rank1 + "," + pref1; 
        String tuple2 = rank2 + "," + pref2; 
        String tuple3 = rank3 + "," + pref3; 
        String tuple4 = rank4 + "," + pref4; 
        String tuple5 = rank5 + "," + pref5; 
        String tuple6 = rank6 + "," + pref6; 
        String tuple7 = rank7 + "," + pref7; 
              
        UserPref preference = new UserPref();
         
        //Sets the userPrefrences object with the users preferences
        preference.setUserid(username); 
        preference.setPreferenceOne(tuple1);
        preference.setPreferenceTwo(tuple2);
        preference.setPreferenceThree(tuple3);
        preference.setPreferenceFour(tuple4);
        preference.setPreferenceFive(tuple5);
        preference.setPreferenceSix(tuple6);
        preference.setPreferenceSeven(tuple7);
         
         
        //The core Logic of the Registration application is present here. We are going to insert user data in to the database.
         String userPreferenceSet= UserDao.registerPref(preference);
            
         if(userPreferenceSet.equals("SUCCESS"))   //On success, you can display a message to user on Home page
         {
            request.getRequestDispatcher("/userPref.jsp").forward(request, response);
        }
        else   //On Failure, display a meaningful message to the User.
       {
            request.setAttribute("errMessage", userPreferenceSet);
            request.getRequestDispatcher("userPref.jsp").forward(request, response);
         }
     }
}
