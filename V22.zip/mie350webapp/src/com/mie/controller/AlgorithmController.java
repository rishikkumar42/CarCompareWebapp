package com.mie.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mie.dao.CarDao;
import com.mie.util.DbUtil;

public class AlgorithmController extends HttpServlet {
	/**
	 * This class only handles the Algorithm feature of the web app.
	 * 
	 * These are variables that lead to the appropriate JSP pages.
	 * 
	 * RECCOMENDATION_USER leads to the search results page.
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static String ALGO_RESULT = "/algoResult.jsp";
	private CarDao dao;
	private Connection connection = null;

	/**
	 * Constructor for this class.
	 */
	public AlgorithmController() {
		super();
		dao = new CarDao();
		connection = DbUtil.getConnection();
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		/**
		 * This method handles the retrieval of the preferences entered by
		 * the user.
		 */
		HttpSession session = request.getSession();
		String username = (String) session.getAttribute("username");
		
		List<String> preferenceList = new ArrayList();
		List<String> preferenceListValue = new ArrayList();
		String forward = "";
		
		PreparedStatement preparedStatement;
		try {
			preparedStatement = connection.prepareStatement("Select * from UserPref_R Where username = ?");
			preparedStatement.setString(1, username);//how to make work for current user.
			ResultSet rs = preparedStatement.executeQuery();
			
			for(int i = 0; i< ((ArrayList<String>) rs).size(); i++){
				String[] splitted = rs.getString(i).split(",");
				preferenceList.add(splitted[0]);
				preferenceListValue.add(splitted[1]);
			}
			forward = ALGO_RESULT; 
			request.setAttribute("CarModels_R", dao.getCarByPreference(preferenceList, preferenceListValue));
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		//request.setAttribute("CarModels_R", dao.getCarByPreference(preferenceList, preferenceListValue));
		RequestDispatcher view = request.getRequestDispatcher(forward);
		view.forward(request, response);
		
	}

}
