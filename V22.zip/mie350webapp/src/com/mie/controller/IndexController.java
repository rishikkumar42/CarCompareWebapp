package com.mie.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mie.dao.CarDao;
import com.mie.dao.GenCarDao;
import com.mie.model.Car;

public class IndexController extends HttpServlet {
	/**
	 * This class only handles the HOME PAGE of the app
	 * 
	 * These are variables that lead to the appropriate JSP pages.
	 * 
	 * HOME_PAGE leads to the index.jsp page with is the main home page that displays top cars and other links
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static String HOME_PAGE = "/index.jsp";
	private static String HOME_PAGE_LOG = "/indexLogged.jsp";
	private GenCarDao dao;

	/**
	 * Constructor for this class.
	 */
	public IndexController() {
		super();
		dao = new GenCarDao();
	}
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {

		/**
		 * This class retrieves the appropriate 'action' found on the JSP pages:
		 * 
		 * - delete will direct the servlet to let the user delete a student in
		 * the database. - insert will direct the servlet to let the user add a
		 * new student to the database. - edit will direct the servlet to let
		 * the user edit student information in the database. - listStudent will
		 * direct the servlet to the public listing of all students in the
		 * database. - listStudentAdmin will direct the servlet to the admin
		 * listing of all students in the database.
		 */
		String forward = "";
		String action = request.getParameter("action");

		if (action.equalsIgnoreCase("index")) {

			forward = HOME_PAGE;
			request.setAttribute("Car_R", dao.getTopCarModels());
		}
		else if (action.equals("indexLog")){
			forward = HOME_PAGE_LOG;
			request.setAttribute("Car_R", dao.getTopCarModels());
		}
		RequestDispatcher view = request.getRequestDispatcher(forward);
		view.forward(request, response);
	}

	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		/**
		 * This method handles the retrieval of the search keyword entered by
		 * the user.
		 */
		String keyword = request.getParameter("keyword");

		RequestDispatcher view = request.getRequestDispatcher(HOME_PAGE);
		request.setAttribute("keyword", keyword);
		request.setAttribute("Car_R", dao.getTopCarModels());
		/**
		 * Redirect to the search results page after the list of students
		 * matching the keywords has been retrieved.
		 */

		view.forward(request, response);
	}
}