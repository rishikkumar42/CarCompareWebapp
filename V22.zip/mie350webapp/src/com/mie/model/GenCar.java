package com.mie.model;

import java.util.Date;

public class GenCar {
	/**
	 * This class contains all of the relevant information, and getter/setter
	 * methods for the Car object.
	 */
	
	//Variables
	private String CarCompany;
	private String CarMake;
	private int Year;
	private int MSRPLow;
	private int MSRPHigh;
	private String Type;
	private String FormFactor;
	 private String ImagePath; 

	// Getters
	public String getCarCompany() {
		return CarCompany;
	}
	public String getCarMake() {
		return CarMake;
	}
	public int getYear() {
		return Year;
	}
	public int getMSRPLow() {
		return MSRPLow;
	}
	public int getMSRPHigh() {
		return MSRPHigh;
	}
	public String getType() {
		return Type;
	}
	public String getFormFactor() {
		return FormFactor;
	}
	public String getImagePath(){
		return ImagePath; 
	}

	// Setters
	public void setCarCompany(String company) {
		this.CarCompany = company;
	}
	public void setCarMake(String carmake) {
		this.CarMake = carmake;
	}
	public void setYear(int year) {
		this.Year = year;
	}
	public void setMSRPLow(int msrp) {
		this.MSRPLow = msrp;
	}
	public void setMSRPHigh(int msrp1) {
		this.MSRPHigh = msrp1;
	}
	public void setType(String type) {
		this.Type = type;
	}
	public void setFormFactor(String FormFactor) {
		this.FormFactor = FormFactor;
	}

	public void setImagePath(String imgPath){
		this.ImagePath = imgPath; 
	}

	@Override
	public String toString() {
		return "Car [CarCompany=" + CarCompany + ", CarMake=" + CarMake + ", Year=" + Year + ", MSRPLow=" + MSRPLow + ", MSRPHigh=" + MSRPHigh + ", Type="
				+ Type + ", FormFactor=" + FormFactor + ", imgPath=" + ImagePath + "]";
	}
	
}