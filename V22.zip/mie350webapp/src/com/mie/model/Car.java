package com.mie.model;

import java.util.Date;

public class Car {
	/**
	 * This class contains all of the relevant information, and getter/setter
	 * methods for the Car object.
	 */
	
	//Variables
	private int CarID;
	private String CarModel;
	private String CarMake;
	private int MSRP;
	private String TypeSpec;
	private String HorsePower;
	private String EnginerCap;
	private String cylinders;
	private String Transmission;
	private int Seats;
	private String DriveTrain;
	private int CityMPG;
	private int HighwayMPG;
	private int CombinedMPG;
	private String ImagePath; 
	private String drivetrainName; 
	private String typespecName; 
	private String transmissionName; 

	// Getters
	public int getCarID() {
		return CarID;
	}
	public String getCarModel() {
		return CarModel;
	}
	public String getCarMake() {
		return CarMake;
	}
	public int getMSRP() {
		return MSRP;
	}
	public String getTypeSpec() {
		return TypeSpec;
	}
	public String getHorsePower() {
		return HorsePower;
	}
	public String getEnginerCap() {
		return EnginerCap;
	}
	public String getcylinders() {
		return cylinders;
	}
	public String getTransmission() {
		return Transmission;
	}
	public int getSeats() {
		return Seats;
	}
	
	public String getDriveTrain() {
		return DriveTrain;
	}
	
	public int getCityMPG() {
		return CityMPG;
	}
	
	public int getHighwayMPG() {
		return HighwayMPG;
	}
	
	public int getCombinedMPG() {
		return CombinedMPG;
	}
	
	public String getImagePath(){
		return ImagePath; 
	}

	// Setters
	public void setCarID(int carID) {
		this.CarID = carID;
	}
	public void setCarModel(String carmodel) {
		this.CarModel = carmodel;
	}
	public void setCarMake(String carmake) {
		this.CarMake = carmake;
	}
	public void setMSRP(int msrp) {
		this.MSRP = msrp;
	}
	public void setTypeSpec(String typespec) {
		this.TypeSpec = typespec;
	}
	public void setHorsePower(String HorsePower) {
		this.HorsePower = HorsePower;
	}
	public void setEnginerCap(String EnginerCap) {
		this.EnginerCap = EnginerCap;
	}
	public void setcylinders(String cylinders) {
		this.cylinders = cylinders;
	}
	public void setTransmission(String transmission) {
		this.Transmission = transmission;
	}
	public void setSeats(int seats) {
		this.Seats = seats;
	}
	public void setDriveTrain(String drivetrain) {
		this.DriveTrain = drivetrain;
	}
	public void setCityMPG(int citympg) {
		this.CityMPG = citympg;
	}
	public void setHighwayMPG(int highwaympg) {
		this.HighwayMPG = highwaympg;
	}
	public void setCombinedMPG(int combinedmpg) {
		this.CombinedMPG = combinedmpg;
	}
	public void setImagePath(String imgPath){
		this.ImagePath = imgPath; 
	}

	@Override
	public String toString() {
		return "Car [CarID=" + CarID + ", CarModel=" + CarModel
				+ ", CarMake=" + CarMake + ", MSRP=" + MSRP + ", TypeSpec="
				+ TypeSpec + ", HorsePower=" + HorsePower + ", EnginerCap=" + EnginerCap + ", cylinders=" + cylinders + ", Transmission=" + Transmission 
				+ ", Seats=" + Seats + ", DriveTrain=" + DriveTrain + ", CityMPG=" + CityMPG 
				+ ", HighwayMPG=" + HighwayMPG + ", CombinedMPG=" + CombinedMPG + ", ImagePath=" + ImagePath + "]";
	}
	public String getDrivetrainName() {
		return drivetrainName;
	}
	public void setDrivetrainName(String drivetrainName) {
		this.drivetrainName = drivetrainName;
	}
	public String getTypespecName() {
		return typespecName;
	}
	public void setTypespecName(String typespecName) {
		this.typespecName = typespecName;
	}
	public String getTransmissionName() {
		return transmissionName;
	}
	public void setTransmissionName(String transmissionName) {
		this.transmissionName = transmissionName;
	}
	
}