package com.mie.model;

public class UserSavedList {
	
	private String username;
	private int carid; 
	private String carMake; 
	private String carModel; 
	private int year;
	private int MSRP;
	private String imgPath; 
	
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public int getCarid() {
		return carid;
	}
	public void setCarid(int carid) {
		this.carid = carid;
	}
	public String getCarMake() {
		return carMake;
	}
	public void setCarMake(String carMake) {
		this.carMake = carMake;
	}
	public String getCarModel() {
		return carModel;
	}
	public void setCarModel(String carModel) {
		this.carModel = carModel;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getMSRP() {
		return MSRP;
	}
	public void setMSRP(int mSRP) {
		MSRP = mSRP;
	} 
	
	@Override
	public String toString() {
		return "UserPref [username=" + username + ", carid=" + carid + ", carMake=" + carMake + ", carModel=" + carModel + ", year=" + year + ", MSRP=" + MSRP+ "]"; 
				
	}
	public String getImgPath() {
		return imgPath;
	}
	public void setImgPath(String imgPath) {
		this.imgPath = imgPath;
	}
	
	
	

}
