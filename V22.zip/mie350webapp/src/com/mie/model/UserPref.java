package com.mie.model;

import java.util.ArrayList;
import java.util.Date;

public class UserPref {
	/**
	 * This class contains all of the relevant information, and getter/setter
	 * methods for the User object.
	 */
	private String userid;
	private String pref1;
	private String pref2;
	private String pref3;
	private String pref4;
	private String pref5;
	private String pref6;
	private String pref7;
	private boolean valid;



	public String getUserid() {
		return userid;
	}

	public void setUserid(String username) {
		this.userid = username;
	}
	
	//Preference Setters
	public void setPreferenceOne(String preferenceOne) {
		this.pref1 = preferenceOne;
	}
	public void setPreferenceTwo(String preferenceTwo) {
		this.pref2 = preferenceTwo;
	}
	public void setPreferenceThree(String preferenceThree) {
		this.pref3 = preferenceThree;
	}
	public void setPreferenceFour(String preferenceFour) {
		this.pref4 = preferenceFour;
	}
	public void setPreferenceFive(String preferenceFive) {
		this.pref5 = preferenceFive;
	}
	public void setPreferenceSix(String preferenceSix) {
		this.pref6 = preferenceSix;
	}
	public void setPreferenceSeven(String preferenceSeven) {
		this.pref7 = preferenceSeven;
	}
	
	//Preference Getters
	public String getPreferenceOne() {
		return pref1;
	}
	public String getPreferenceTwo() {
		return pref2;
	}
	public String getPreferenceThree() {
		return pref3;
	}
	public String getPreferenceFour() {
		return pref4;
	}
	public String getPreferenceFive() {
		return pref5;
	}
	public String getPreferenceSix() {
		return pref6;
	}
	public String getPreferenceSeven() {
		return pref7;
	}

	public boolean isValid() {
		return valid;
	}

	public void setValid(boolean newValid) {
		valid = newValid;
	}

	@Override
	public String toString() {
		return "Preferences [userid=" + userid + ", pref1=" + pref1
				+ ", pref2=" + pref2 + ", pref3=" + pref3
				+ ", pref4=" + pref4 + ", pref5=" + pref5 + ", pref6=" + pref6 + ", pref7=" + pref7+ "]";
	}
}